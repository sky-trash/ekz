<?php
require_once 'Library.php';

echo "=== тест 1: Добавление книги ===\n";
$library = new Library();

// добавляем книгу
$book = $library->addBook("Война и мир", "Лев Толстой", "123-1-12-123123-1", 1234);
echo "Книга создана\n";

// проверяем ID
echo "ID книги: " . $book->id . " (ожидается 1) - " . ($book->id == 1 ? "да" : "нет") . "\n";

// проверяем название
echo "Название: " . $book->title . " (ожидается Война и мир) - " . ($book->title == "Война и мир" ? "да" : "нет") . "\n";

// проверяем автора
echo "Автор: " . $book->author . " (ожидается Лев Толстой) - " . ($book->author == "Лев Толстой" ? "да" : "нет") . "\n";

// проверяем год
echo "Год: " . $book->year . " (ожидается 1234) - " . ($book->year == 1234 ? "да" : "нет") . "\n";

// проверяем доступность
echo "Доступность: " . ($book->isAvailable ? "true" : "false") . " (ожидается true) - " . ($book->isAvailable == true ? "да" : "нет") . "\n";

// проверяем количество книг
$bookCount = count($library->getAllBooks());
echo "Всего книг: " . $bookCount . " (ожидается 1) - " . ($bookCount == 1 ? "да" : "нет") . "\n";

echo "\n=== тест 2: Выдача книги читателю ===\n";
$library2 = new Library();

// подготовка: добавляем книгу и читателя
$book = $library2->addBook("Книга", "Автор", "123", 1234);
$reader = $library2->addReader("Читатель");
echo "Подготовка: книга и читатель созданы\n";

// выдаем книгу
$borrow = $library2->borrowBook($book->id, $reader->id);
echo "Выдача создана, ID выдачи: " . $borrow->id . "\n";

// проверяем ID книги
echo "ID книги в выдаче: " . $borrow->bookId . " (ожидается " . $book->id . ") - " . ($borrow->bookId == $book->id ? "да" : "нет") . "\n";

// проверяем ID читателя
echo "ID читателя в выдаче: " . $borrow->readerId . " (ожидается " . $reader->id . ") - " . ($borrow->readerId == $reader->id ? "да" : "нет") . "\n";

// проверяем дату возврата
echo "Дата возврата: " . ($borrow->returnDate === null ? "null" : $borrow->returnDate) . " (ожидается null) - " . ($borrow->returnDate === null ? "да" : "нет") . "\n";

// проверяем доступность книги
$updatedBook = $library2->findBook($book->id);
echo "Книга доступна: " . ($updatedBook->isAvailable ? "true" : "false") . " (ожидается false) - " . ($updatedBook->isAvailable == false ? "да" : "нет") . "\n";

// проверяем список доступных книг
$availableCount = count($library2->getAvailableBooks());
echo "Доступных книг: " . $availableCount . " (ожидается 0) - " . ($availableCount == 0 ? "да" : "нет") . "\n";

// проверяем активные выдачи
$activeCount = count($library2->getActiveBorrows());
echo "Активных выдач: " . $activeCount . " (ожидается 1) - " . ($activeCount == 1 ? "да" : "нет") . "\n";

echo "\n=== тест 3: Возврат книги ===\n";
$library3 = new Library();

// подготовка: создаем книгу, читателя и выдаем книгу
$book = $library3->addBook("Книга", "Автор", "123", 1234);
$reader = $library3->addReader("Читатель");
$borrow = $library3->borrowBook($book->id, $reader->id);
echo "Подготовка: книга выдана (ID выдачи: " . $borrow->id . ")\n";

// проверяем состояние до возврата
$beforeAvailable = !$library3->findBook($book->id)->isAvailable;
$beforeActive = count($library3->getActiveBorrows());
echo "До возврата - Книга недоступна: " . ($beforeAvailable ? "true" : "false") . " ✓\n";
echo "До возврата - Активных выдач: " . $beforeActive . " (ожидается 1) - " . ($beforeActive == 1 ? "да" : "нет") . "\n";

// возвращаем книгу
$result = $library3->returnBook($borrow->id);
echo "Результат возврата: " . ($result ? "true" : "false") . " (ожидается true) - " . ($result == true ? "да" : "нет") . "\n";

// проверяем дату возврата
$afterBorrow = null;
foreach ($library3->getActiveBorrows() as $active) {
    if ($active->id == $borrow->id) {
        $afterBorrow = $active;
    }
}
// получаем запись о выдаче через рефлексию простым способом
$borrowRecord = $borrow;
$reflection = new ReflectionClass($library3);
$property = $reflection->getProperty('borrows');
$property->setAccessible(true);
$borrows = $property->getValue($library3);
$updatedBorrow = $borrows[$borrow->id];

echo "Дата возврата: " . ($updatedBorrow->returnDate ?: "null") . " (ожидается не null) - " . ($updatedBorrow->returnDate !== null ? "да" : "нет") . "\n";

// проверяем доступность книги после возврата
$afterAvailable = $library3->findBook($book->id)->isAvailable;
echo "Книга доступна после возврата: " . ($afterAvailable ? "true" : "false") . " (ожидается true) - " . ($afterAvailable == true ? "да" : "нет") . "\n";

// проверяем активные выдачи после возврата
$afterActive = count($library3->getActiveBorrows());
echo "Активных выдач после возврата: " . $afterActive . " (ожидается 0) - " . ($afterActive == 0 ? "да" : "нет") . "\n";

echo "\n Все тесты завершены!\n";
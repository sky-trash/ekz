<?php

class Book {
    public $id;
    public $title;
    public $author;
    public $year;
    public $isAvailable;
    
    public function __construct($title, $author, $year) {
        $this->title = $title;
        $this->author = $author;
        $this->year = $year;
        $this->isAvailable = true;
    }
}

class Reader {
    public $id;
    public $name;
    
    public function __construct($name) {
        $this->name = $name;
    }
}

class BorrowRecord {
    public $id;
    public $bookId;
    public $readerId;
    public $returnDate;
    
    public function __construct($bookId, $readerId) {
        $this->bookId = $bookId;
        $this->readerId = $readerId;
        $this->returnDate = null;
    }
}

class Library {
    private $books = [];
    private $readers = [];
    private $borrows = [];
    private $nextBookId = 1;
    private $nextReaderId = 1;
    private $nextBorrowId = 1;
    
    // добавление книги
    public function addBook($title, $author, $year) {
        $book = new Book($title, $author, $year);
        $book->id = $this->nextBookId++;
        $this->books[$book->id] = $book;
        return $book;
    }
    
    // регистрация читателя
    public function addReader($name) {
        $reader = new Reader($name);
        $reader->id = $this->nextReaderId++;
        $this->readers[$reader->id] = $reader;
        return $reader;
    }
    
    // выдача книги
    public function borrowBook($bookId, $readerId) {
        $book = $this->books[$bookId];
        $reader = $this->readers[$readerId];
        
        if (!$book->isAvailable) {
            return false;
        }
        
        $borrow = new BorrowRecord($bookId, $readerId);
        $borrow->id = $this->nextBorrowId++;
        $this->borrows[$borrow->id] = $borrow;
        
        $book->isAvailable = false;
        
        return $borrow;
    }
    
    // возврат книги
    public function returnBook($borrowId) {
        if (!isset($this->borrows[$borrowId])) {
            return false;
        }
        
        $borrow = $this->borrows[$borrowId];
        $borrow->returnDate = date('Y-m-d H:i:s');
        
        $book = $this->books[$borrow->bookId];
        $book->isAvailable = true;
        
        return true;
    }
    
    public function getAllBooks() {
        return $this->books;
    }
    
    public function getAvailableBooks() {
        $available = [];
        foreach ($this->books as $book) {
            if ($book->isAvailable) {
                $available[] = $book;
            }
        }
        return $available;
    }
    
    // получить активные выдачи
    public function getActiveBorrows() {
        $active = [];
        foreach ($this->borrows as $borrow) {
            if ($borrow->returnDate === null) {
                $active[] = $borrow;
            }
        }
        return $active;
    }
    
    public function findBook($id) {
        return isset($this->books[$id]) ? $this->books[$id] : null;
    }
}